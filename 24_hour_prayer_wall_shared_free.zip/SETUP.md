# 24-HOUR PRAYER WALL — SHARED FREE SETUP

The website is designed to use:
• Supabase Free for the shared prayer database
• A free static host such as GitHub Pages for the website

Supabase's current Free plan includes a Postgres database and 500 MB database size per project. Free projects can pause after one week of inactivity, so this is best viewed as a free starter/community project rather than a guaranteed always-on commercial service.

## 1. Create the free database
Go to the official Supabase website and create a free account.
Create a new project.

## 2. Create the prayer table
Open Supabase Dashboard → SQL Editor.
Open `supabase.sql` from this folder.
Paste it into the SQL Editor and run it.

## 3. Get your two connection values
In Supabase, open your project's Connect/API settings.
Copy:
• Project URL
• Publishable/anon key

NEVER copy the `service_role` or secret key into the website.

## 4. Put the values into index.html
Open `index.html` and find:

const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY_HERE";

Replace only those two placeholders.

## 5. Test before publishing
Open the page in a browser.
Submit a test prayer.
It should say the prayer is waiting for moderation.

In Supabase → Table Editor → prayers:
change that test prayer's `approved` value from false to true.

Refresh the website. It should now appear on the wall.

Click "I Prayed For This" to test the counter.

## 6. Publish the website for free
GitHub Pages can publish static HTML/CSS/JavaScript from a GitHub repository under GitHub Free.

Create a GitHub repository and upload `index.html`.
Then open Settings → Pages and choose your publishing source.
GitHub will give you a free `github.io` website address.

## IMPORTANT MODERATION
Because strangers can submit prayers, moderation is strongly recommended. This version keeps submissions hidden until you approve them in Supabase.

For the first version, you can approve/reject requests manually in Supabase.
A later version can add a private admin login and an approval dashboard.

## PRIVACY / SAFETY
Do not ask people to post highly sensitive personal information.
The site should clearly tell visitors not to include addresses, phone numbers, passwords, medical records, etc.
Consider adding a report button and a written moderation policy before opening it widely.

## 24-HOUR BEHAVIOR
The public query only displays:
approved=true AND created_at >= now() - 24 hours

So old prayers automatically disappear from the public wall after 24 hours, even if they remain stored in the database.
